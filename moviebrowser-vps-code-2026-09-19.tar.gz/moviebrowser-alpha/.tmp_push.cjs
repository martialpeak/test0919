
const esbuild = require("esbuild");
const fs = require("fs");
esbuild.buildSync({
  entryPoints: ["src/data/initialMovies.ts"],
  bundle: true, format: "cjs", outfile: ".tmp_init.cjs", external: ["../types"]
});
const { INITIAL_MOVIES } = require("./.tmp_init.cjs");
fs.writeFileSync(".tmp_movies.json", JSON.stringify(INITIAL_MOVIES));
console.log("count:", INITIAL_MOVIES.length);
